# Base de Datos II — Kevin Michue Huaman

Repositorio de trabajo del curso **Base de Datos II**, organizado en **4 unidades** de **4 semanas** cada una (16 semanas en total).

## Cómo navegar este repositorio

- **`index.html`** — panel interactivo del curso: abre cada unidad, revisa temas y actividades de cada semana, y marca tu avance semana a semana. Ábrelo directamente en el navegador, o publícalo con GitHub Pages (ver abajo) para tener una URL propia.
- **Carpetas `Unidad-1` a `Unidad-4`** — el contenido de cada unidad, con una subcarpeta `Semana-1` a `Semana-4` por dentro.
- Cada carpeta de semana trae:
  - `README.md` con objetivo, temas, actividades y notas.
  - `recursos/` para guardar scripts SQL, documentos o material propio de esa semana.

```
Kevin-Michue-Huaman/
├── index.html
├── Unidad-1/
│   ├── README.md
│   ├── Semana-1/ (README.md + recursos/)
│   ├── Semana-2/
│   ├── Semana-3/
│   └── Semana-4/
├── Unidad-2/  (misma estructura)
├── Unidad-3/  (misma estructura)
└── Unidad-4/  (misma estructura)
```

## Unidades

| Unidad | Tema |
|---|---|
| 1 | Fundamentos avanzados y modelado de bases de datos |
| 2 | Programación y objetos almacenados en el motor |
| 3 | Transacciones, concurrencia y seguridad |
| 4 | Administración, rendimiento y bases de datos distribuidas |

Los temas y actividades de cada semana son un punto de partida editable — ajústalos al sílabo real de tu curso, tanto en cada `README.md` como en la lista `COURSE` dentro de `index.html`.

## Publicar el panel con GitHub Pages

1. Ve a **Settings → Pages** en el repositorio.
2. En "Source", elige la rama `main` y la carpeta `/ (root)`.
3. Guarda; GitHub te dará una URL como `https://<tu-usuario>.github.io/Kevin-Michue-Huaman/`.

## Actualizar contenido semana a semana

1. Edita el `README.md` de la semana correspondiente con tus apuntes reales.
2. Agrega tus archivos (scripts `.sql`, diagramas, documentos) dentro de la carpeta `recursos/` de esa semana.
3. Confirma los cambios:

```bash
git add .
git commit -m "Unidad X · Semana Y: avance"
git push
```

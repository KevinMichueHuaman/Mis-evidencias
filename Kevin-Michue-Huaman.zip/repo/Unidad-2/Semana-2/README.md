# Unidad 2 · Semana 2

**Curso:** Base de Datos II
**Unidad:** 2 — Programación y objetos almacenados en el motor

## Objetivo de la semana
_Describe aquí el objetivo de aprendizaje de esta semana._

## Temas
- Tema 1
- Tema 2
- Tema 3

## Actividades
- [ ] Lectura / material de clase
- [ ] Ejercicio práctico
- [ ] Entregable de la semana

## Recursos
Coloca aquí los archivos, scripts SQL o documentos de esta semana (carpeta `recursos/`).

## Notas
_Espacio libre para apuntes propios._

# Unidad 3 — Transacciones, concurrencia y seguridad

**Curso:** Base de Datos II
**Alumno:** Kevin Michue Huaman

Esta unidad se organiza en 4 semanas:

| Semana | Enlace |
|---|---|
| Semana 1 | [Semana-1](./Semana-1) |
| Semana 2 | [Semana-2](./Semana-2) |
| Semana 3 | [Semana-3](./Semana-3) |
| Semana 4 | [Semana-4](./Semana-4) |

Cada carpeta de semana contiene su propio `README.md` con objetivo, temas, actividades y una subcarpeta `recursos/` para materiales y scripts.
